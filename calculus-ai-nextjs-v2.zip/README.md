# Calculus AI Tutor

An AI-powered calculus learning platform built with Next.js.

## Features
- Ask calculus questions
- AI tutor integration ready
- Deployable on Vercel

## Getting Started

```bash
npm install
npm run dev
```
