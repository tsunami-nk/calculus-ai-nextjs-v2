export const metadata={title:'Calculus AI Tutor'};
export default function RootLayout({children}){
 return <html><body>{children}</body></html>
}