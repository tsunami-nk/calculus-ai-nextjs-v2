'use client';
import {useState} from 'react';
export default function Home(){
 const [q,setQ]=useState('');
 const [a,setA]=useState('');
 return (
 <main style={{padding:20}}>
 <h1>Calculus AI Tutor</h1>
 <textarea value={q} onChange={e=>setQ(e.target.value)} />
 <button onClick={()=>setA('Connect AI API: '+q)}>Ask</button>
 <p>{a}</p>
 </main>
 )
}